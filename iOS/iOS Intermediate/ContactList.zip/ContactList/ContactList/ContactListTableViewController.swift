//
//  ContactListTableViewController.swift
//  ContactList
//
//  Created by Betalantz on 9/21/17.
//  Copyright © 2017 Betalantz. All rights reserved.
//

import UIKit
import CoreData

class ContactListTableViewController: UITableViewController, AddEditViewControllerDelegate, ShowViewControllerDelegate {
    
    // *************
    // Global variables and setup
    // *************
    
    var contacts = [Contact]()
    
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func fetchAllContacts() {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Contact")
        do {
            let result = try managedObjectContext.fetch(request)
            contacts = result as! [Contact]
        } catch {
            print("\(error)")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchAllContacts()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // *************
    // Populating and Rendering table view
    // *************

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactListCell", for: indexPath)
        let currContact = contacts[indexPath.row]
        cell.textLabel?.text = "\(currContact.firstName!) \(currContact.lastName!)"
        cell.detailTextLabel?.text = currContact.number
        return cell
    }
    

    // *************
    // Segues
    // *************
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segueToAddView" {
            let navigationController = segue.destination as! UINavigationController
            let addEditViewController = navigationController.topViewController as! AddEditViewController
            addEditViewController.delegate = self
            addEditViewController.navigationItem.title = "New Contact"
            
            if let selectedContact: Contact = sender as? Contact {
                addEditViewController.contactToEdit = selectedContact
                let textAttributes = [NSAttributedStringKey.foregroundColor:UIColor.white]
                navigationController.navigationBar.titleTextAttributes = textAttributes
                addEditViewController.navigationItem.title = "Edit Contact"
            }
        } else if segue.identifier == "segueToShowView" {
                let navigationController = segue.destination as! UINavigationController
                let showViewController = navigationController.topViewController as! ShowViewController
                showViewController.delegate = self
            
            if let selectedContact: Contact = sender as? Contact {
                showViewController.contactToShow = selectedContact
                showViewController.navigationItem.title = selectedContact.firstName
            }
        }
    }
    
    // **************
    // Create and Update Operations
    // **************
    
    func savePressed(sender: AddEditViewController) {
        var contactItem: Contact?
        if let _ = sender.contactToEdit {
            contactItem = sender.contactToEdit!
        } else {
            contactItem = (NSEntityDescription.insertNewObject(forEntityName: "Contact", into: managedObjectContext) as! Contact)
            contacts.append(contactItem!)
        }
        contactItem!.firstName = sender.firstNameTextField.text
        contactItem!.lastName = sender.lastNameTextField.text
        contactItem!.number = sender.numberTextField.text
        do {
            try managedObjectContext.save()
            
        } catch {
            print("\(error)")
        }
        self.tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    // **************
    // Alert Controller
    // **************
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: nil,
                                      message: nil,
                                      preferredStyle: .alert)
        let view = UIAlertAction(title: "View", style: .default, handler: { (action) -> Void in
            print("View selected!")
            let currContact = self.contacts[indexPath.row]
            self.performSegue(withIdentifier: "segueToShowView", sender: currContact)
        })
        
        let edit = UIAlertAction(title: "Edit", style: .default, handler: { (action) -> Void in
            print("Edit selected!")
            let currContact = self.contacts[indexPath.row]
            print(currContact)
            self.performSegue(withIdentifier: "segueToAddView", sender: currContact)
        })
        let delete = UIAlertAction(title: "Delete", style: .destructive, handler: { (action) -> Void in
            print("Delete selected!")
            let currContact = self.contacts[indexPath.row]
            self.managedObjectContext.delete(currContact)
            do {
                try self.managedObjectContext.save()
            } catch {
                print("\(error)")
            }
            self.contacts.remove(at: indexPath.row)
            tableView.reloadData()
        })
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) -> Void in
            print("Cancel selected!")
        })
        alert.addAction(view)
        alert.addAction(edit)
        alert.addAction(delete)
        alert.addAction(cancel)
        present(alert, animated: true, completion: nil)
    }
   
}
