//
//  ViewController.swift
//  ContactList
//
//  Created by Betalantz on 9/21/17.
//  Copyright © 2017 Betalantz. All rights reserved.
//

import UIKit

protocol AddEditViewControllerDelegate: class {
    func savePressed(sender: AddEditViewController)
}

class AddEditViewController: UIViewController {

    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var numberTextField: UITextField!
    
    var delegate: AddEditViewControllerDelegate?
    var contactToEdit: Contact?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let currContact = contactToEdit {
            firstNameTextField.text = currContact.firstName
            lastNameTextField.text = currContact.lastName
            numberTextField.text = currContact.number
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func saveButtonPressed(_ sender: UIBarButtonItem) {
        delegate?.savePressed(sender: self)
    }
    
    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
}

