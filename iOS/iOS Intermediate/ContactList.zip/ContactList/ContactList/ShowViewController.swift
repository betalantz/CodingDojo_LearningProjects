//
//  ShowViewController.swift
//  ContactList
//
//  Created by Betalantz on 9/21/17.
//  Copyright © 2017 Betalantz. All rights reserved.
//

import UIKit

protocol ShowViewControllerDelegate: class {
}

class ShowViewController: UIViewController {

    @IBOutlet weak var showNameLabel: UILabel!
    @IBOutlet weak var showNumberLabel: UILabel!
    
    weak var delegate: ShowViewControllerDelegate?
    var contactToShow: Contact?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let display = contactToShow {
            showNameLabel.text = "\(display.firstName!) \(display.lastName!)"
            showNumberLabel.text = display.number
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func doneButtonPressed(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
 

}
